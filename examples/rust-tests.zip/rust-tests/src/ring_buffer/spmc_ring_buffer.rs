//! Reference Single-Producer / Multi-Consumer (SPMC) ring buffer + test hooks.
//!
//! # Contract under test
//!
//! * **Const-generic sizing.** `SpmcRingBuffer<T, CAP, N>` — `CAP` is the
//!   (power-of-two) capacity, `N` the number of consumers. Both are compile-time
//!   constants so the compiler monomorphizes/specializes each configuration.
//!   `CAP` being a power of two is enforced at compile time (`const CHECK`), so
//!   the slot index is a mask (`i & (CAP - 1)`).
//! * **Fan-out semantics.** Every consumer independently observes *every*
//!   produced item, in FIFO order, with **no gaps**.
//! * **Fail-on-full.** `try_push` returns `Err(item)` (the item handed back)
//!   when the buffer is full; it never overwrites unconsumed data. The buffer
//!   is full when the *slowest* consumer is `CAP` items behind the producer.
//!   `push` spins on `try_push` until it succeeds.
//! * **Asymmetric visibility.**
//!     - Producer -> consumers: **immediate** (release store / acquire load).
//!     - Consumers -> producer: **lazy**. The producer keeps a plain cached
//!       snapshot of the slowest consumer and only refreshes it (with `Acquire`
//!       loads) on the `try_push` *slow path*, i.e. when the cache says "full".
//!       A consumer's progress may therefore be invisible to the producer for a
//!       while — until the next full-check re-queries.
//! * **Safety invariant (the important one):** the producer's cached view of
//!   consumer progress is a *conservative lower bound* — it may lag reality
//!   (stale-behind) but must NEVER read ahead of reality (stale-ahead). A
//!   stale-ahead read would let the producer reclaim a slot a consumer still
//!   needs, corrupting the stream.
//! * **Consumers must not disappear.** A registered consumer that stops
//!   consuming permanently stalls the producer (by design). `push`/`pop` spin
//!   forever in that situation; tests assert this backpressure via `try_*`.
//!
//! # Memory ordering summary
//!
//! | site                                   | ordering | why                                             |
//! |----------------------------------------|----------|-------------------------------------------------|
//! | producer store to `write` (try_push)   | Release  | publish slot write to consumers                 |
//! | consumer load of `write` (try_pop)     | Acquire  | see the producer's published slot               |
//! | consumer store to `read[id]` (try_pop) | Release  | publish progress to the producer                |
//! | producer refresh of `read[..]` (slow)  | Acquire  | producer acts on it -> must sync w/ consumer     |
//! | `cached_min_consumer_index()` (hook)   | plain    | producer-owned field, no cross-thread sync       |
//! | `true_min_consumer_index()` (hook)     | Acquire  | must not under-report -> avoid flaky violation    |
//!
//! # Feature gates
//!
//! * `test-hooks` (default ON) — exposes inspection methods
//!   (`true_min_consumer_index`, `id`, `read_index`, `write_index`) to the
//!   INTEGRATION tests under `tests/`. Those are separate crates that link the
//!   lib WITHOUT `cfg(test)`, so `cfg(test)` would hide the hooks from them — a
//!   feature is the correct gate. Production consumers use
//!   `default-features = false`.
//! * `loom` — swaps std atomics/cells for loom's instrumented ones. Enable with
//!   `--features loom` (preferred over the older `--cfg loom` RUSTFLAGS trick).
//!
//! # How to plug in YOUR implementation
//!
//! Keep the public API (`SpmcRingBuffer::<T, CAP, N>::new`, `get_new_producer`,
//! `get_new_consumer`, `Producer::try_push`/`push`, `Consumer::try_pop`/`pop`)
//! and the inspection hooks. Route all shared state through the `sync` module so
//! loom can instrument it (see README "loom" section).

// ---------------------------------------------------------------------------
// sync shim: std types normally, loom types under `--features loom`.
//
// EVERY atomic and cell in the buffer MUST come from here, or loom is blind to
// it. The ONLY place production and loom diverge is the slot-access API (loom's
// UnsafeCell requires the closure `with`/`with_mut` form; production uses raw
// pointer arithmetic). That split lives in `Inner::read_slot`/`write_slot`.
// ---------------------------------------------------------------------------
pub(crate) mod sync {
    #[cfg(feature = "loom")]
    pub(crate) use loom::cell::UnsafeCell;
    #[cfg(feature = "loom")]
    pub(crate) use loom::sync::atomic::{AtomicUsize, Ordering};
    #[cfg(feature = "loom")]
    pub(crate) use loom::sync::Arc;

    #[cfg(not(feature = "loom"))]
    pub(crate) use std::cell::UnsafeCell;
    #[cfg(not(feature = "loom"))]
    pub(crate) use std::sync::atomic::{AtomicUsize, Ordering};
    #[cfg(not(feature = "loom"))]
    pub(crate) use std::sync::Arc;
}

use sync::{Arc, AtomicUsize, Ordering, UnsafeCell};

// ---------------------------------------------------------------------------
// Shared inner state.
//
// Positions are *monotonically increasing* global indices (never wrapped). The
// physical slot for index `i` is `i & (CAP - 1)` (CAP is a power of two). Using
// unbounded indices removes the classic "full vs empty?" ambiguity: the buffer
// holds `write - min(read cursors)` live items.
// ---------------------------------------------------------------------------
struct Inner<T, const CAP: usize, const N: usize> {
    /// Backing storage: one interior-mutable cell PER slot. This per-slot
    /// layout is what makes the structure loom-checkable without a storage
    /// fallback (loom sees each slot access independently).
    slots: [UnsafeCell<Option<T>>; CAP],

    /// Producer write index. Released by producer, acquired by consumers.
    write: AtomicUsize,

    /// Per-consumer read indices. `read[c]` is released by consumer `c` and
    /// (lazily) acquired by the producer on the try_push slow path.
    read: [AtomicUsize; N],

    /// How many consumers have been registered (bounds the min-scan to the
    /// consumers that actually exist). Never exceeds `N` (the registration
    /// CAS in `get_new_consumer` returns `None` instead of incrementing past
    /// `N`).
    num_consumers: AtomicUsize,

    /// 0 = producer not yet issued; 1 = producer already issued. The CAS in
    /// `get_new_producer` enforces single-issuance, returning `None` on a
    /// second call.
    producer_issued: AtomicUsize,
}

// SAFETY: access to `slots[i]` is disciplined by the write/read indices and
// their release/acquire ordering: the producer only writes a slot no consumer
// can yet observe (index >= write), and consumers only read slots the producer
// has released (index < write). T must be Send to cross threads.
unsafe impl<T: Send, const CAP: usize, const N: usize> Send for Inner<T, CAP, N> {}
unsafe impl<T: Send, const CAP: usize, const N: usize> Sync for Inner<T, CAP, N> {}

impl<T, const CAP: usize, const N: usize> Inner<T, CAP, N> {
    /// Compile-time guard: CAP must be a power of two (and thus > 0). Forced to
    /// evaluate by touching `Self::CHECK` in every public constructor.
    const CHECK: () = assert!(
        CAP.is_power_of_two(),
        "SpmcRingBuffer capacity CAP must be a power of two"
    );

    #[inline]
    fn mask(index: usize) -> usize {
        index & (CAP - 1)
    }

    /// Write a slot. PRODUCTION uses raw pointer arithmetic off the array base
    /// (this is the hot path you care about); LOOM uses the instrumented
    /// closure API so it can track the access. Only this line differs between
    /// the two builds — the surrounding index/ordering logic is identical.
    #[inline]
    fn write_slot(&self, index: usize, value: Option<T>) {
        let idx = Self::mask(index);
        #[cfg(not(feature = "loom"))]
        // SAFETY: exclusive to the producer for this index (see type comment).
        unsafe {
            let base = self.slots.as_ptr() as *mut UnsafeCell<Option<T>>;
            *(*base.add(idx)).get() = value;
        }
        #[cfg(feature = "loom")]
        self.slots[idx].with_mut(|p| unsafe { *p = value });
    }

    /// Read (clone) a slot. Same production/loom split as `write_slot`.
    #[inline]
    fn read_slot(&self, index: usize) -> Option<T>
    where
        T: Clone,
    {
        let idx = Self::mask(index);
        #[cfg(not(feature = "loom"))]
        // SAFETY: the caller has established index < write via an Acquire load,
        // so the producer's release of this slot happens-before this read.
        unsafe {
            let base = self.slots.as_ptr() as *const UnsafeCell<Option<T>>;
            (*(*base.add(idx)).get()).clone()
        }
        #[cfg(feature = "loom")]
        {
            self.slots[idx].with(|p| unsafe { (*p).clone() })
        }
    }

    /// True minimum read index across all *registered* consumers, loaded with
    /// `Acquire`. This is the ground truth the producer's cache must never
    /// overtake. `Acquire` guarantees we never *under*-report consumer progress
    /// (which would make a `cached <= true` check spuriously fail).
    fn true_min_read(&self) -> usize {
        let n = self.num_consumers.load(Ordering::Acquire);
        if n == 0 {
            return self.write.load(Ordering::Acquire);
        }
        let mut m = usize::MAX;
        for c in 0..n {
            let r = self.read[c].load(Ordering::Acquire);
            if r < m {
                m = r;
            }
        }
        m
    }
}

// ---------------------------------------------------------------------------
// Public handle.
// ---------------------------------------------------------------------------
pub struct SpmcRingBuffer<T, const CAP: usize, const N: usize> {
    inner: Arc<Inner<T, CAP, N>>,
}

impl<T, const CAP: usize, const N: usize> SpmcRingBuffer<T, CAP, N> {
    /// Create a ring buffer of capacity `CAP` for `N` consumers.
    /// Fails to COMPILE (via `Inner::CHECK`) if `CAP` is not a power of two.
    pub fn new() -> Self {
        // Force the compile-time power-of-two assertion to be evaluated.
        let () = Inner::<T, CAP, N>::CHECK;

        Self {
            inner: Arc::new(Inner {
                slots: std::array::from_fn(|_| UnsafeCell::new(None)),
                write: AtomicUsize::new(0),
                read: std::array::from_fn(|_| AtomicUsize::new(0)),
                num_consumers: AtomicUsize::new(0),
                producer_issued: AtomicUsize::new(0),
            }),
        }
    }

    /// Obtain the (single) producer handle. Returns `None` if a producer has
    /// already been issued (single-producer invariant enforced by a CAS on
    /// `producer_issued`, not by a "call at most once" doc comment).
    pub fn get_new_producer(&self) -> Option<Producer<T, CAP, N>> {
        match self
            .inner
            .producer_issued
            .compare_exchange(0, 1, Ordering::AcqRel, Ordering::Acquire)
        {
            Ok(_) => Some(Producer {
                inner: self.inner.clone(),
                cached_min_read: 0, // pessimistic start
            }),
            Err(_) => None,
        }
    }

    /// Register a new consumer. Returns `None` if all `N` slots are taken
    /// (instead of panicking). Uses a CAS loop so `num_consumers` never
    /// exceeds `N` (a plain `fetch_add` would let it overshoot, breaking
    /// the OOB-bounded `read[c]` scan in `true_min_read`).
    pub fn get_new_consumer(&self) -> Option<Consumer<T, CAP, N>> {
        loop {
            let cur = self.inner.num_consumers.load(Ordering::Acquire);
            if cur >= N {
                return None;
            }
            if self
                .inner
                .num_consumers
                .compare_exchange(cur, cur + 1, Ordering::AcqRel, Ordering::Acquire)
                .is_ok()
            {
                return Some(Consumer {
                    inner: self.inner.clone(),
                    id: cur,
                });
            }
            // Another thread claimed slot `cur`; retry.
        }
    }
}

impl<T, const CAP: usize, const N: usize> Default for SpmcRingBuffer<T, CAP, N> {
    fn default() -> Self {
        Self::new()
    }
}

impl<T, const CAP: usize, const N: usize> Clone for SpmcRingBuffer<T, CAP, N> {
    fn clone(&self) -> Self {
        Self {
            inner: self.inner.clone(),
        }
    }
}

// ---------------------------------------------------------------------------
// Producer.
// ---------------------------------------------------------------------------
pub struct Producer<T, const CAP: usize, const N: usize> {
    inner: Arc<Inner<T, CAP, N>>,
    /// The producer's *lazy* cached view of the slowest consumer. A PLAIN
    /// producer-owned field (not shared, not atomic): reading it needs no
    /// memory ordering. It must remain a conservative lower bound of reality.
    cached_min_read: usize,
}

// Single producer: may move between threads, must never be duplicated.
unsafe impl<T: Send, const CAP: usize, const N: usize> Send for Producer<T, CAP, N> {}

impl<T, const CAP: usize, const N: usize> Producer<T, CAP, N> {
    /// Non-blocking push. `Ok(())` on success; `Err(item)` hands the item back
    /// when the buffer is full so the caller can retry without losing it.
    ///
    /// Lazy refresh: try against the (possibly stale) cache first; only on a
    /// "full" verdict do we pay for a fresh Acquire read of the consumer
    /// indices and retry once. This is the "producer misses consumer updates
    /// until it re-queries" behaviour, and the refresh happens HERE (never as a
    /// standalone operation).
    pub fn try_push(&mut self, item: T) -> Result<(), T> {
        let write = self.inner.write.load(Ordering::Relaxed); // producer owns write

        // Fast path against the cached snapshot (no consumer read, no Acquire).
        if write.wrapping_sub(self.cached_min_read) < CAP {
            self.commit(write, item);
            return Ok(());
        }

        // Slow path: re-query real consumer positions (Acquire), retry once.
        self.cached_min_read = self.inner.true_min_read();
        if write.wrapping_sub(self.cached_min_read) < CAP {
            self.commit(write, item);
            Ok(())
        } else {
            Err(item) // full — hand the item back
        }
    }

    /// Blocking push: spin on `try_push` until it succeeds. Never drops the
    /// item (it is reused across attempts).
    ///
    /// # Deadlock
    /// If a registered consumer never advances, the buffer stays full and this
    /// spins forever (by design — see the "consumers must not disappear"
    /// contract). Only call when consumers are guaranteed to make progress.
    pub fn push(&mut self, item: T) {
        let mut item = item;
        loop {
            match self.try_push(item) {
                Ok(()) => return,
                Err(returned) => {
                    item = returned;
                    core::hint::spin_loop();
                }
            }
        }
    }

    #[inline]
    fn commit(&mut self, write: usize, item: T) {
        // SAFETY: index `write` is not yet visible to any consumer.
        self.inner.write_slot(write, Some(item));
        // Release: publishes the slot write; consumers Acquire it via `write`.
        self.inner
            .write
            .store(write.wrapping_add(1), Ordering::Release);
    }

    // ---- inspection hooks -------------------------------------------------

    /// The producer's *cached* (lazy) view of the slowest consumer index.
    /// PLAIN field read: this value is producer-owned, so no memory ordering
    /// applies. It is deliberately stale between try_push slow-path refreshes.
    pub fn cached_min_consumer_index(&self) -> usize {
        self.cached_min_read
    }

    /// The *true* current slowest consumer index (Acquire loads), bypassing the
    /// cache. Test-only (behind `test-hooks`): asserts `cached <= true`.
    #[cfg(feature = "test-hooks")]
    pub fn true_min_consumer_index(&self) -> usize {
        self.inner.true_min_read()
    }

    /// Current producer write index (number of items ever pushed).
    #[cfg(feature = "test-hooks")]
    pub fn write_index(&self) -> usize {
        self.inner.write.load(Ordering::Relaxed)
    }
}

// ---------------------------------------------------------------------------
// Consumer.
// ---------------------------------------------------------------------------
pub struct Consumer<T, const CAP: usize, const N: usize> {
    inner: Arc<Inner<T, CAP, N>>,
    id: usize,
}

unsafe impl<T: Send, const CAP: usize, const N: usize> Send for Consumer<T, CAP, N> {}

impl<T: Clone, const CAP: usize, const N: usize> Consumer<T, CAP, N> {
    /// Non-blocking pop for *this* consumer. `None` if it has caught up to the
    /// producer. Fan-out: each consumer has an independent cursor and clones
    /// the value out of the slot.
    pub fn try_pop(&self) -> Option<T> {
        let read = self.inner.read[self.id].load(Ordering::Relaxed); // consumer owns its idx
        // Acquire the producer's write index: immediate producer->consumer
        // visibility, and synchronises-with the producer's slot release.
        let write = self.inner.write.load(Ordering::Acquire);
        if read >= write {
            return None; // caught up
        }
        let val = self.inner.read_slot(read);
        let val = val.expect("slot < write must be populated");
        // Release our progress so the producer can (lazily) Acquire it later.
        self.inner.read[self.id].store(read.wrapping_add(1), Ordering::Release);
        Some(val)
    }

    /// Blocking pop: spin on `try_pop` until an item is available.
    ///
    /// # Deadlock
    /// Spins forever if the producer never publishes another item. Only call
    /// when a producer is guaranteed to make progress.
    pub fn pop(&self) -> T {
        loop {
            if let Some(v) = self.try_pop() {
                return v;
            }
            core::hint::spin_loop();
        }
    }

    /// This consumer's current read index (items it has consumed so far).
    #[cfg(feature = "test-hooks")]
    pub fn read_index(&self) -> usize {
        self.inner.read[self.id].load(Ordering::Relaxed)
    }

    /// This consumer's stable id (0-based registration order).
    #[cfg(feature = "test-hooks")]
    pub fn id(&self) -> usize {
        self.id
    }
}
