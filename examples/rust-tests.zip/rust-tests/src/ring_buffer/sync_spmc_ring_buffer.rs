//! Locked SPMC ring buffer — straightforward `Mutex`-guarded stand-in.
//!
//! Same public API as [`super::spmc_ring_buffer::SpmcRingBuffer`] so the
//! benchmark harness can drive both backends through the `RingBuffer` trait
//! (see `src/bench/backend.rs`). This is a *stand-in*: a simple, obviously
//! correct locked implementation. Swap it for your real locked impl later,
//! keeping the same signatures.
//!
//! # Semantics (mirror the lock-free reference)
//!
//! * **Fan-out**: every consumer independently sees every item, FIFO, no gaps
//!   (pop is `T: Clone` — each consumer clones the value out of the slot).
//! * **Fail-on-full**: `try_push` returns `Err(item)` (hands it back, never
//!   overwrites); `push` spins until success. The buffer is full when the
//!   slowest registered consumer is `CAP` items behind the producer.
//! * **Backpressure**: a registered consumer that stops consuming permanently
//!   stalls the producer (by design); `push`/`pop` spin forever.
//!
//! # The defining performance characteristic (for the comparison suite)
//!
//! A SINGLE `Mutex` guards the entire state, so every `try_push` and every
//! `try_pop` (across ALL consumers) is fully serialised. There is no
//! concurrent consumer parallelism — this is exactly what the lock-free
//! impl's fan-out exploits, and it is the dimension where the two backends
//! should diverge hardest (see the N-scaling comparison, Group F).

use std::sync::{Arc, Mutex};

// ---------------------------------------------------------------------------
// Shared inner state (under the mutex).
//
// Positions are *monotonically increasing* global indices (never wrapped),
// mirroring the lock-free reference. The physical slot for index `i` is
// `i & (CAP - 1)` (CAP is a power of two).
// ---------------------------------------------------------------------------
struct Inner<T, const CAP: usize, const N: usize> {
    /// Backing storage. A fixed array (structurally parallel to the lock-free
    /// impl's `[UnsafeCell<Option<T>>; CAP]`) — no `Vec` heap indirection on
    /// the hot path.
    slots: [Option<T>; CAP],

    /// Producer write index (monotonic, unwrapped).
    write: usize,

    /// Per-consumer read indices (monotonic, unwrapped).
    read: [usize; N],

    /// How many consumers have been registered (bounds the min-scan).
    num_consumers: usize,

    /// Whether a producer has been issued (single-producer invariant).
    producer_issued: bool,
}

/// Locked SPMC ring buffer, `Mutex`-guarded. See module docs.
pub struct SyncRingBuffer<T, const CAP: usize, const N: usize> {
    inner: Arc<Mutex<Inner<T, CAP, N>>>,
}

impl<T, const CAP: usize, const N: usize> SyncRingBuffer<T, CAP, N> {
    /// Compile-time guard: CAP must be a power of two (and thus > 0).
    const CHECK: () = assert!(
        CAP.is_power_of_two(),
        "SyncRingBuffer capacity CAP must be a power of two"
    );

    /// Create a ring buffer of capacity `CAP` for up to `N` consumers.
    /// Fails to COMPILE (via `Self::CHECK`) if `CAP` is not a power of two.
    pub fn new() -> Self {
        let () = Self::CHECK;
        Self {
            inner: Arc::new(Mutex::new(Inner {
                slots: std::array::from_fn(|_| None),
                write: 0,
                read: [0; N],
                num_consumers: 0,
                producer_issued: false,
            })),
        }
    }

    /// Obtain the (single) producer handle. Returns `None` if a producer has
    /// already been issued (single-producer invariant enforced under the
    /// mutex, not by a "call at most once" doc comment).
    pub fn get_new_producer(&self) -> Option<SyncProducer<T, CAP, N>> {
        let mut guard = self.inner.lock().unwrap();
        if guard.producer_issued {
            return None;
        }
        guard.producer_issued = true;
        Some(SyncProducer {
            inner: self.inner.clone(),
        })
    }

    /// Register a new consumer. Returns `None` if all `N` slots are taken
    /// (instead of panicking).
    pub fn get_new_consumer(&self) -> Option<SyncConsumer<T, CAP, N>> {
        let id = {
            let mut guard = self.inner.lock().unwrap();
            if guard.num_consumers >= N {
                return None;
            }
            let id = guard.num_consumers;
            guard.num_consumers += 1;
            id
        };
        Some(SyncConsumer {
            inner: self.inner.clone(),
            id,
        })
    }
}

impl<T, const CAP: usize, const N: usize> Default for SyncRingBuffer<T, CAP, N> {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Producer.
//
// `Send` is auto-derived: `Arc<Mutex<Inner>>: Send` when `Inner: Send`, which
// holds when `T: Send`. No explicit `unsafe impl` needed (unlike the
// lock-free impl, which uses raw `UnsafeCell` + pointer arithmetic).
// ---------------------------------------------------------------------------
pub struct SyncProducer<T, const CAP: usize, const N: usize> {
    inner: Arc<Mutex<Inner<T, CAP, N>>>,
}

impl<T, const CAP: usize, const N: usize> SyncProducer<T, CAP, N> {
    /// Non-blocking push. `Ok(())` on success; `Err(item)` hands the item back
    /// when the buffer is full.
    ///
    /// Every `try_push` takes the mutex — compare with the lock-free impl's
    /// fast path (no lock, no consumer read). Under backpressure this path is
    /// taken repeatedly; `push` spins on it.
    pub fn try_push(&mut self, item: T) -> Result<(), T> {
        let mut guard = self.inner.lock().unwrap();
        let min_read = min_read(&guard);
        if guard.write.wrapping_sub(min_read) < CAP {
            let slot = guard.write & (CAP - 1);
            guard.slots[slot] = Some(item);
            guard.write = guard.write.wrapping_add(1);
            Ok(())
        } else {
            Err(item) // full — hand the item back
        }
    }

    /// Blocking push: spin on `try_push` until it succeeds. Never drops the
    /// item (it is reused across attempts).
    ///
    /// # Deadlock
    /// If a registered consumer never advances, the buffer stays full and this
    /// spins forever (by design — same contract as the lock-free impl).
    pub fn push(&mut self, item: T) {
        let mut item = item;
        loop {
            match self.try_push(item) {
                Ok(()) => return,
                Err(returned) => {
                    item = returned;
                    std::hint::spin_loop();
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Consumer.
//
// `Send + Sync` are auto-derived (same reasoning as the producer; `id: usize`
// is `Send + Sync`). Each consumer's `try_pop`/`pop` takes the SAME mutex as
// the producer and as every other consumer — i.e. all consumers are fully
// serialised. This is the structural property the comparison suite exploits.
// ---------------------------------------------------------------------------
pub struct SyncConsumer<T, const CAP: usize, const N: usize> {
    inner: Arc<Mutex<Inner<T, CAP, N>>>,
    id: usize,
}

impl<T: Clone, const CAP: usize, const N: usize> SyncConsumer<T, CAP, N> {
    /// Non-blocking pop for *this* consumer. `None` if it has caught up to the
    /// producer. Fan-out: each consumer has an independent cursor and clones
    /// the value out of the slot.
    pub fn try_pop(&self) -> Option<T> {
        let mut guard = self.inner.lock().unwrap();
        let read = guard.read[self.id];
        if read >= guard.write {
            return None; // caught up
        }
        let slot = read & (CAP - 1);
        let val = guard.slots[slot].clone();
        guard.read[self.id] = read.wrapping_add(1);
        val
    }

    /// Blocking pop: spin on `try_pop` until an item is available.
    ///
    /// # Deadlock
    /// Spins forever if the producer never publishes another item.
    pub fn pop(&self) -> T {
        loop {
            if let Some(v) = self.try_pop() {
                return v;
            }
            std::hint::spin_loop();
        }
    }
}

// ---------------------------------------------------------------------------
// Helpers.
// ---------------------------------------------------------------------------

/// True minimum read index across all *registered* consumers, matching the
/// lock-free reference's `true_min_read` semantics. With zero consumers
/// registered, returns `write` (so `write - write = 0 < CAP` is always
/// pushable — the 0-consumer edge case; never hit in the benchmark, which
/// registers consumers before producing).
fn min_read<T, const CAP: usize, const N: usize>(inner: &Inner<T, CAP, N>) -> usize {
    let n = inner.num_consumers;
    if n == 0 {
        return inner.write;
    }
    let mut m = usize::MAX;
    for c in 0..n {
        if inner.read[c] < m {
            m = inner.read[c];
        }
    }
    m
}
