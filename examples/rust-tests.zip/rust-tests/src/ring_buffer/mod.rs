//! Ring buffer backends.
//!
//! Two interchangeable implementations sharing the same public API so the
//! benchmark harness can drive either through the `RingBuffer` trait (see
//! `src/bench/backend.rs`):
//!
//!   * [`spmc_ring_buffer`] — lock-free SPMC ring buffer (the reference impl
//!     lives here as a stand-in; swap in your real lock-free impl keeping the
//!     same API + inspection hooks).
//!   * [`sync_spmc_ring_buffer`] — straightforward `Mutex`-guarded stand-in
//!     ([`SyncRingBuffer`](sync_spmc_ring_buffer::SyncRingBuffer)). Swap in
//!     your real locked impl keeping the same signatures.
//!
//! Both are sized with const generics `<T, CAP, N>` where `CAP` is a power of
//! two (compile-time checked).

pub mod spmc_ring_buffer;
pub mod sync_spmc_ring_buffer;
