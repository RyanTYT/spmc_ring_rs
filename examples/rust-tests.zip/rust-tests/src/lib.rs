//! `spmc-ring` — SPMC ring buffer backends + (opt-in) benchmark harness.
//!
//! Two interchangeable ring-buffer backends live under [`ring_buffer`]:
//!
//!   * [`ring_buffer::spmc_ring_buffer::SpmcRingBuffer`] — lock-free SPMC
//!     (the reference impl lives here as a stand-in; swap in your real
//!     lock-free impl keeping the same API + inspection hooks).
//!   * [`ring_buffer::sync_spmc_ring_buffer::SyncRingBuffer`] — locked
//!     stand-in. Swap in your real locked impl keeping the same signatures.
//!
//! Both share the same const-generic `<T, CAP, N>` API (`new`,
//! `get_new_producer`, `get_new_consumer`, `try_push`/`push`,
//! `try_pop`/`pop`) so the benchmark harness can drive either through a
//! single backend-agnostic trait.
//!
//! # Cargo features
//!
//! | Feature | Default | Purpose |
//! |---|---|---|
//! | `test-hooks` | ON | Inspection hooks for the integration tests under `tests/`. |
//! | `loom` | off | Swap std atomics/cells for loom's instrumented ones. |
//! | `heavy-stress` | off | Million-iteration stress runs. |
//! | `bench` | off | Benchmark harness + example binaries (`src/bench/`, `examples/`). |
//!
//! Production builds use `--no-default-features` so the test hooks and the
//! benchmark harness are not compiled into shipped code.

pub mod ring_buffer;

// Convenience re-exports so call sites stay short (and the existing test suite
// under tests/ keeps one-line imports).
pub use ring_buffer::spmc_ring_buffer::{Consumer, Producer, SpmcRingBuffer};
pub use ring_buffer::sync_spmc_ring_buffer::{SyncConsumer, SyncProducer, SyncRingBuffer};

// The benchmark harness. Gated behind `bench` so production builds
// (--no-default-features) never link it. Filled in by a later phase.
#[cfg(feature = "bench")]
pub mod bench;
